<html>
<head>
<meta http-dquiv="Content-Type" content="text/html" charset="utf-8">
</head>
<body>


<link href="http://ncpms.rda.go.kr/css/api.css" rel="stylesheet" type="text/css"><!-- CSS 선언 -->
<script type="text/javascript" src="http://ncpms.rda.go.kr/js/framework.js"></script><!-- 공통 JS 선언 -->	
<script type="text/javascript" src="http://ncpms.rda.go.kr/js/openapi_dngss.js"></script><!-- 공통 JS 선언 -->

<script type="text/javascript">

npmsApiRequestInfo.apiKey = "";//apiKey - NCPMS에서 신청 후 승인되면 확인 가능
npmsApiRequestInfo.serviceCode = "SVC11"; // 사진검색 1의 서비스코드(상세한 내용은 Open API 이용안내 참조)

npmsApiRequestInfo.callback = "http://yourDomain.go.kr/dgnss_ajax_local_callback.jsp";//Call Back URL : 제공하는 callBack 페이지를 서버에 배포후 해당 경로를 적용

</script>
<!-- HTML 로딩 영역(DIV 태그의 ID는 변경 금지) -->
<div id="npms_api_data"></div>

</body>
</html>